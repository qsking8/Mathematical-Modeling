function y = Obj_fun1(x)
    y = 11*sin(x) + 7*cos(5*x);
end